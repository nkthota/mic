# Prompt for GitHub Copilot (Agent mode)

Copy this folder into the repo (e.g. `docs/design/reqnroll-report/`), open Copilot Chat in **Agent** mode, attach the folder with `#` file references, and paste the prompt below. Optionally copy the "Standing rules" section into `.github/copilot-instructions.md`.

---

```
#file:docs/design/reqnroll-report/README.md
#file:docs/design/reqnroll-report/report-data.schema.json
#file:docs/design/reqnroll-report/sample-report-data.json
#file:docs/design/reqnroll-report/design-reference.html

Implement a self-contained HTML test execution report for our Reqnroll test framework,
matching the attached design reference exactly (layout, colours, typography, interactions
documented in README.md).

Do this in steps and stop for my review after each:

1. Explore the solution and list: our existing reporting events/listeners (UI actions with
   XPath, HTTP/SOAP request/response logging, screenshots, video, logger), Reqnroll hooks
   already in use, and where test output is written. Propose where the new code lives.

2. Create C# model classes matching report-data.schema.json (System.Text.Json, camelCase).

3. Create a ReportCollector that subscribes to our existing events and Reqnroll hooks
   ([BeforeTestRun], [BeforeFeature], [BeforeScenario], [AfterStep], [AfterScenario],
   [AfterTestRun]) and builds the model. It must be thread-safe for parallel execution
   (key state by ScenarioContext / pickle id). Attach UI and HTTP events to the step that
   is currently executing. Mask secrets (passwords, tokens, Authorization headers).
   Pretty-print JSON and XML bodies.

4. Create report-template.html as an embedded resource: one file, inline CSS + vanilla JS,
   no network requests, reads data from
   <script type="application/json" id="report-data">__REPORT_DATA__</script>.
   Recreate every section of design-reference.html. Use sample-report-data.json as the
   dev fixture so the template can be opened standalone.

5. Create ReportWriter that serialises the model, escapes "</" in the JSON, injects it into
   the template, embeds screenshots as base64 and copies large files (video/trace/HAR) to
   attachments/ beside the report, and writes TestResults/reqnroll-report.html.

6. Read Azure DevOps predefined variables (listed in README) into run.meta; fall back to
   local values when not running in a pipeline.

7. Add the azure-pipelines.yml steps to publish the report folder as a pipeline artifact
   (condition: always()).

8. Add unit tests for the collector (step attribution, outline rows, failure capture) and
   a snapshot test that renders the template with sample-report-data.json.
```

---

## Standing rules (optional `.github/copilot-instructions.md`)

- The report must be a single HTML file with zero external requests; large attachments may sit in a sibling `attachments/` folder.
- Report data shape is defined by `report-data.schema.json` — update the schema first when adding fields.
- Never write raw secrets into the report; mask values for fields named password/secret/token and Authorization/Cookie headers.
- Design tokens (colours, fonts, radii) come from the README's Design tokens table — don't invent new ones.
