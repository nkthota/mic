# Handoff: Reqnroll Test Execution Report

## Overview
A single, self-contained HTML report produced at the end of an Azure Pipelines run of Reqnroll (BDD) tests. Its job is to let a developer/QA debug a failed scenario **without leaving the file**: failure summary, stack trace, failed Gherkin step, per-step UI actions (XPath, input, expected/actual), per-step HTTP request/response payloads (JSON or XML), Scenario Outline example row, data tables/doc strings, attachments (screenshots, video, traces) and the scenario's log output.

## About the design files
`design-reference.html` is a **design reference built in HTML** — a working prototype with hard-coded sample data showing intended look and behaviour. It is **not** the production template. The task is to build a report generator in our test framework that emits an HTML file with this look and behaviour, populated from our real reporting events.

Open `design-reference.html` in a browser to explore it (click scenarios in the tree, expand steps, ↑/↓ to move between scenarios).

## Fidelity
**High-fidelity.** Recreate colours, typography, spacing and interactions as documented below.

---

## Recommended architecture

```
Reqnroll hooks / framework reporting events
        │  (BeforeScenario, AfterStep, AfterScenario, our UI + HTTP events)
        ▼
ReportCollector  ──►  ReportModel (C# POCOs matching report-data.schema.json)
        │
        ▼  [AfterTestRun]
ReportWriter
   1. Serialize ReportModel → JSON
   2. Read embedded template report-template.html
   3. Replace the placeholder inside
      <script type="application/json" id="report-data">__REPORT_DATA__</script>
   4. Inline attachments as data: URIs (or write beside the file, see below)
   5. Write TestResults/reqnroll-report.html
        │
        ▼
Azure Pipeline: PublishPipelineArtifact (+ optional publishHtmlReport tab)
```

Rules for the template (`report-template.html`, to be written):
- **One file, zero network requests.** Inline all CSS/JS; inline fonts as base64 `@font-face` (IBM Plex Sans 400/500/600/700, IBM Plex Mono 400/500/600 — both OFL) or fall back to `system-ui` / `Consolas`.
- Vanilla JS (or a pre-bundled tiny library) that reads `JSON.parse(document.getElementById('report-data').textContent)` and renders. No build step needed at test time.
- Escape `</script` in the JSON (`.Replace("</", "<\\/")`) since payloads may contain HTML/XML.
- Must stay responsive at <100 scenarios (current scale); no virtualisation required.

### Data sources → model
| Model field | Source |
|---|---|
| `run.*` | Azure DevOps predefined variables: `BUILD_BUILDNUMBER`, `BUILD_SOURCEBRANCHNAME`, `BUILD_SOURCEVERSION`, `BUILD_SOURCEVERSIONMESSAGE`, `BUILD_REASON`, `SYSTEM_PULLREQUEST_PULLREQUESTNUMBER`, `BUILD_REQUESTEDFOR`, `AGENT_NAME`, `AGENT_OS`, `SYSTEM_COLLECTIONURI`+`SYSTEM_TEAMPROJECT`+`BUILD_BUILDID` (run link). Env/browser/base-URL from our test config. |
| `features[].scenarios[]` name, tags, line, outline row | `FeatureContext.FeatureInfo`, `ScenarioContext.ScenarioInfo` (`Title`, `Tags`, `Arguments` for outline rows), Reqnroll Cucumber Messages (`pickle`, `gherkinDocument`) for file/line and example tables |
| `steps[]` keyword/text/table/docString/status/duration | `ScenarioContext.StepContext.StepInfo` in `[AfterStep]`; status from `ScenarioContext.ScenarioExecutionStatus` / `TestError`; or Cucumber Messages `testStepFinished` |
| `steps[].ui` (action, xpath, value, expected, actual) | **Our framework's UI reporting events** — attach to the current step |
| `steps[].http` (request/response) | **Our framework's HTTP/SOAP reporting events** (HttpClient `DelegatingHandler` or existing logger) — attach to the current step |
| `error` | `ScenarioContext.TestError` (type, message, stack); failed step = the step whose status is Failed; binding = `StepContext.StepInfo.BindingMatch.StepBinding.Method` |
| `logs[]` | Our logger sink scoped per scenario (timestamp, level, message) |
| `attachments[]` | Screenshot/video/trace paths produced by our framework on failure |
| Cross-check | TRX (`TestResults/*.trx`) can be used to verify counts/outcomes but is not required as primary input |

### Attachments
- Screenshots (< ~500 KB): embed as `data:image/png;base64,…`.
- Videos / traces / HAR: embedding bloats the file. Default: copy next to the HTML in `attachments/` and link relatively; publish the folder in the same pipeline artifact. Provide a config flag `EmbedLargeAttachments` (default false).

The data contract is in `report-data.schema.json`; a complete example is in `sample-report-data.json`.

---

## Screens / layout
Single page, max width fluid, page background `#F4F7FB`, body font IBM Plex Sans, text `#14213D`.

### 1. Header (full-width, background `#0047BB`, text white, padding 20px 32px 24px, gap 18px)
- Kicker row (13px): `REQNROLL TEST REPORT` (700, letter-spacing .08em, uppercase) | pipeline name | link "Open run in Azure DevOps ↗" (white, underlined).
- Title row: `Build {buildNumber}` 32px/700, letter-spacing -.01em. Next to it a white pill (radius 6px, padding 4px 12px) with red `#B3261E` text "N of M failed" + circle-x icon. Hide pill when 0 failed (show green "All passed").
- Stats (left, flex 1 1 360px): five figures — Scenarios, Passed, Failed, Skipped, Duration — value 28px/700, label 12px at 85% opacity, gap 28px. Below: 8px stacked bar (radius 4px, track `#00338A`, gap 2px) passed `#7FD18B`, failed `#FF8A80`, skipped `#AFC3E6`, widths = percentage of total.
- Run metadata panel (flex 2 1 520px, bg `#00338A`, radius 8px, padding 12px 16px): auto-fill grid `minmax(180px,1fr)`, gap 10px 20px. Label 11px/600 uppercase `#AFC3E6`; value 13px, wraps anywhere. Fields: Branch, Commit, Trigger, Requested by, Started, Agent, Environment, Browser, Runtime, Runner.

### 2. Body (padding 24px 32px 40px, flex-wrap, gap 24px)

**Left: Feature tree** (flex 1 1 280px, max 360px, sticky top 16px, white, border 1px `#D9E1EC`, radius 8px)
- Header "Features" 15px/700 + hint "↑ ↓ to move" 12px `#5B6B82`.
- Feature row (bg `#F8FAFD`, hover `#E6EEFA`, padding 10px 14px): chevron (rotates 90° when open, .15s), name 14px/600, red badge "N failed" (bg `#FDECEA`, text `#B3261E`, 11px/700, radius 4px) if any, then "passed/total".
- Scenario row (padding 7px 14px 7px 34px, 13px): 16px status dot (passed `#2E8B47` ✓, failed `#D32F2F` ✕, skipped `#8A97A8` –), name, duration (IBM Plex Mono 11px). Selected: bg `#E6EEFA`, 3px left border `#0047BB`, weight 600.
- Default: features containing a failure are expanded; fully passing ones collapsed.

**Right: Detail pane** (flex 999 1 560px, column, gap 20px). All cards: white, border 1px `#D9E1EC`, radius 8px, padding 18–20px 24px.

a. **Scenario header**: breadcrumb (feature name `#0047BB` 600 › `file:line` mono 12px), title 24px/700, chips: status (uppercase 12px/700, radius 4px; passed `#E3F3E6`/`#1E7B34`, failed `#FDECEA`/`#B3261E`, skipped `#EDF0F4`/`#4A5568`), duration (mono, bg `#EDF1F6`), tags (border `#C6D7F2`, text `#00338A`). Skipped scenarios show the ignore reason.

b. **Failure card** (only if failed; border `#F1B5AF`, top border 4px `#D32F2F`):
- "Failure" 17px/700 red with warning icon; right: outlined button "Copy error" (border/text `#0047BB`, hover bg `#E6EEFA`) → copies `name, file:line, type: message, full stack`. Label becomes "Copied" for 1.5s.
- Exception type (mono 13px/600 `#B3261E`), message in `<pre>` (bg `#FDF3F2`, radius 6px, mono 13px, pre-wrap).
- Definition grid: Failed step (keyword bold + text), Binding (mono), Thrown at (mono `file:line`).
- Stack trace: shows only frames from our test assembly by default (`#00338A`, 600); toggle "Show all N frames" / "Only test code" reveals framework frames (`#5B6B82`, 400). Mono 12px, line-height 1.65, bg `#F4F7FB`, horizontal scroll (wrap optional via setting).

c. **Test data · example row X of Y** (Scenario Outline only): table of all example rows, current row highlighted bg `#E6EEFA`, 600, with ▶ marker in `#0047BB`.

d. **Steps** card. Header with "Expand all" / "Collapse all" text buttons. Groups labelled `BACKGROUND` / `SCENARIO` (11px/700 uppercase, `#5B6B82`).
- Each step is a bordered row (border `#E3E9F1`, radius 6px; failed: bg `#FFF8F7`, border `#F1B5AF`; skipped/not-run: 65% opacity). Clickable header (hover `#F1F5FB`): status dot, keyword (14px/700 `#0047BB`, min-width 44px), text with quoted parameters rendered as mono chips (bg `#E6EEFA`, text `#00338A`), right side: content badges (`XPATH`, `TABLE`, `DOC`, `JSON`, `XML` — 10.5px/700, bg `#EDF1F6`), duration (mono 11.5px), chevron (hidden if nothing to expand).
- Expanded body (padding 4px 14px 14px 38px, gap 12px):
  - Detail grid: Action, XPath (mono `#00338A` + "Copy" button), Input, Expected (green `#1E7B34`), Actual (green if equals expected, else red `#B3261E`).
  - Data table (mono 12.5px, header bg `#F4F7FB`) / doc string `<pre>`.
  - HTTP panels: two columns `repeat(auto-fit,minmax(280px,1fr))`. **Request**: header bar (bg `#F4F7FB`) "REQUEST", method (mono 600 `#0047BB`), URL (ellipsis), format badge, Copy. **Response**: "RESPONSE", status (green 2xx / red otherwise), elapsed ms, format badge, Copy; non-2xx panel border `#F1B5AF`, header bg `#FDF3F2`. Body `<pre>` mono 12px, max-height 280px, scroll. Pretty-print JSON (2 spaces) and XML (indent) in the generator.
  - The failed step is expanded by default.

e. **Attachments**: grid `minmax(200px,1fr)`; thumbnail 16:10 (bg `#EDF1F6`, radius 6px). Images render inline (click opens full size in a lightbox/new tab), video uses `<video controls>`, other files show an icon + download link. Name + size below.

f. **Log output**: segmented toggle "All (n)" / "Warnings & errors (n)" (selected bg `#0047BB` white text; unselected white bg `#0047BB` text, border `#C6D7F2`). Console panel bg `#0B1F3F`, radius 6px, grid `92px 48px 1fr`: time `HH:MM:SS.mmm` `#7F93B5`, level (INFO `#7FB2FF`, WARN `#FFC870`, ERROR `#FF8A80`, 600), message `#E3EAF5` pre-wrap. ERROR rows bg `rgba(211,47,47,.22)`. Mono 12px.

## Interactions & behaviour
- On load, select the first failed scenario (fallback: first scenario).
- Click scenario → select; its feature auto-expands; step expansion/frame toggle/copied state reset.
- ↑/↓ keys move selection through all scenarios in tree order (ignore when focus is in an input).
- Feature row toggles expand/collapse.
- Step header toggles its body; Expand/Collapse all apply to the current scenario.
- Copy buttons use `navigator.clipboard.writeText`, label → "Copied" for 1.5s.
- Persist selected scenario in `location.hash` (`#scenario=<id>`) so links can be shared — *new, not in prototype*.
- Focus ring: 2px solid `#0047BB`, offset 2px.

## State
`selectedScenarioId`, `collapsedFeatures{}`, `openSteps{}`, `showAllFrames`, `logFilter ('all'|'issues')`, `copiedKey`.

## Design tokens
| Token | Value |
|---|---|
| Primary blue | `#0047BB` |
| Primary dark | `#00338A` |
| Blue tint / hover / selected | `#E6EEFA` |
| Blue border tint | `#C6D7F2` |
| Page bg | `#F4F7FB` |
| Card bg | `#FFFFFF` |
| Border | `#D9E1EC`, inner `#E3E9F1` / `#EDF1F6` |
| Text | `#14213D`, muted `#5B6B82`, secondary `#4A5568` |
| Pass | `#2E8B47` dot, `#1E7B34` text, `#E3F3E6` fill |
| Fail | `#D32F2F` dot, `#B3261E` text, `#FDECEA` fill, `#FDF3F2` / `#FFF8F7` soft, `#F1B5AF` border |
| Skip | `#8A97A8` dot, `#4A5568` text, `#EDF0F4` fill |
| Console | bg `#0B1F3F`, text `#E3EAF5`, time `#7F93B5` |
| Fonts | IBM Plex Sans (UI), IBM Plex Mono (code/data) |
| Radii | 8px cards, 6px controls/panels, 4px chips, 3px badges, 50% dots |
| Type scale | 32 / 28 / 24 / 17 / 16 / 15 / 14 / 13 / 12 / 11 / 10.5 px |

Colours approximate Progressive's palette; replace with official brand values if available.

## Assets
Icons are inline SVG paths from Lucide (circle-x, check, x, minus, chevron-right/down, triangle-alert, copy, image, circle-play, archive). No raster assets.

## Files
- `design-reference.html` — self-contained interactive prototype (sample data).
- `report-data.schema.json` — JSON Schema of the data the template consumes.
- `sample-report-data.json` — one-feature example covering every field.
- `COPILOT_PROMPT.md` — paste into Copilot Chat (agent mode) inside our framework repo.
